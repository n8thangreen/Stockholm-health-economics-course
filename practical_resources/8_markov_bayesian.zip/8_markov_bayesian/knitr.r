library(knitr)
knit2pdf("Solutions.Rnw")
purl("Solutions.Rnw")
